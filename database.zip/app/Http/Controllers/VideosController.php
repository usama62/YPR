<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Videos;

class VideosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['videos'] = Videos::all();
        return view('admin.videos.manage_videos',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.videos.upload_videos');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title'=>'required',
            'description'=>'required',
            'status'=>'required',
            'video_link'=>'required',
        ]);

        $data = new Videos();
        $data->title=$request->title;
        $data->status=$request->status;
        $data->description=$request->description;
        $data->video_link=$request->video_link;
        
        if($data->save()){
            session()->flash('message','Video has been uploaded successfully');
            session()->flash('class','success');
        }else{
            session()->flash('message','Upload failed');
            session()->flash('class','danger');
        }
        
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['video'] = Videos::find($id);
        return view('admin.videos.update',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title'=>'required',
            'status'=>'required',
            'description'=>'required',
        ]);

        $data = new Videos();
        $data->title=$request->title;
        $data->status=$request->status;
        $data->description=$request->description;
        $data->image_path=null;
        
        if($data->save()){
            session()->flash('message','Photo has been uploaded successfully');
            session()->flash('class','success');
        }else{
            session()->flash('message','Upload failed');
            session()->flash('class','danger');
        }
        
        return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Videos::find($id);
        if( $data->delete()){
            session()->flash('message','Video has been deleted successfully');
            session()->flash('class','danger');
        }else{
            session()->flash('message','Delete failed');
            session()->flash('class','danger');
        }
        return back();
    }
}
