<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeHealth extends Model
{
    protected $table = "type_health";
    protected $guard = ['id'];
}
