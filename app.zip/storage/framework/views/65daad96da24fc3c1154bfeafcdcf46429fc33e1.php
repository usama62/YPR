<?php $__env->startSection('content'); ?>
    <div class="jf-breadcrumbarea">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <ol class="jf-breadcrumb">
                        <li><a href="index-2.html">Search</a></li>
                        <li>Search Results</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <main id="jf-main" class="jf-main jf-haslayout">
        <div class="jf-sectionspace jf-haslayout">
            <div class="jf-haslayout">
                <div class="container">
                    <div class="row">
                        <div id="jf-threecolumns">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                                <div class="jf-candidatessearchsvtwo">
                                    <?php $__empty_1 = true; $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="jf-candidatessearcgrid jf-verticaltop">
                                        <div class="jf-candidatessearch">
                                            <figure class="jf-candidatescover">)
                                                <img src="<?php echo e(asset($value->image)); ?>" alt="img-description">	
                                            </figure>
                                            <figure>
                                                <img src="<?php echo e(asset('assets/images/successstory/grid/img-01.png')); ?>" alt="image description">
                                            </figure>
                                            <div class="jf-employerdetails">
                                                <h3><?php echo e($value->title); ?></h3>
                                                <h4><span><?php echo e(str_limit($value->description, 40)); ?></span></h4>
                                                <h4>
                                                    <span>Posted On</span>
                                                    <span><?php echo e(\Carbon\Carbon::parse($value->created_at)->format('M d, Y')); ?></span>
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <div class="text-center">
                                            <img src="<?php echo e(asset('assets/images/no-record.png')); ?>" alt="image description">
                                            <p>No Data Found</p>
                                        </div>	
                                    <?php endif; ?>
                                    <nav class="jf-pagination">
                                        <?php echo e($values->links()); ?>

                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ypr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/search_listing.blade.php ENDPATH**/ ?>