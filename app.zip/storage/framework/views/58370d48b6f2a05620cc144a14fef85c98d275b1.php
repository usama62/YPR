<?php echo e($slot); ?>

<?php /**PATH H:\YPR\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>