<?php $__env->startSection('content'); ?>
	<div class="jf-breadcrumbarea">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<ol class="jf-breadcrumb">
						<li><a href="index-2.html">Home</a></li>
						<li>Blog Details</li>
					</ol>
				</div>
			</div>
		</div>
	</div>
	<main id="jf-main" class="jf-main jf-haslayout">
	<div class="jf-haslayout jf-sectionspace">
		<div class="container">
			<div class="row">
				<div id="jf-twocolumns" class="jf-twocolumns">
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-9 float-left">
						<div class="jf-jobapplycenter jf-jobapplycentervfour">
							<figure class="jf-companyimg">
								<?php if($details->image != null): ?>
                                    <img src="<?php echo e(asset($details->image)); ?>" alt="image description" style="height:72px">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/successstory/grid/img-01.png')); ?>" alt="image description">
                                <?php endif; ?>
							</figure>
							<div class="jf-companycontent">
								<div class="jf-jobapplydetails">
									<div class="jf-companyhead">
										<a class="jf-btnjobtag jf-fulltimejob" href="javascript:void(0);">Full Time Jobs</a>
										<a class="jf-tagfeature" href="javascript:void(0);">feature</a>
									</div>
									<div class="jf-companyname">
										<h3><a href="javascript:void(0);"><?php echo e($details->name); ?></a></h3>
										<ul class="jf-postarticlemetavthree">
                                            <li>
                                                <a href="javascript:void(0);">
                                                    <i class="lnr lnr-calendar-full"></i>
                                                    <span>Posted on <?php echo e(\Carbon\Carbon::parse($details->created_at)->format('M d, Y')); ?></span>
                                                </a>
                                            </li>
                                        </ul>
									</div>
								</div>
								<div class="jf-jobapplybtnlike">
                                    <div class="jf-likebtnbox">
                                        <?php if(count($saved) != 0): ?>
                                        <a class="jf-btnlike jf-btnliked" href="javascript:void(0);"><i class="fa fa-heart-o"></i></a>
                                        <?php endif; ?>
                                    </div>
                                    <ul class="jf-socialiconssimple">
                                        <li class="jf-sharejob"><span>Share</span></li>
										<li class="jf-facebook"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>"><i class="fa fa-facebook-f"></i></a></li>
                                        <li class="jf-twitter"><a href="https://twitter.com/intent/tweet?url=<?php echo e(url()->current()); ?>"><i class="fab fa-twitter"></i></a></li>
                                        <li class="jf-linkedin"><a href="https://plus.google.com/up/?continue=https://plus.google.com/share?url=<?php echo e(url()->current()); ?>"><i class="fab fa-google-plus"></i></a></li>
                                    </ul>
                                </div>
							</div>
						</div>
						<div class="jf-adds jf-addmargin">
							<a href="javascript:void(0);" title="">
								<figure>	
									<img src="<?php echo e(asset('assets/images/adds-03.jpg')); ?>" alt="img description">
								</figure>
							</a>
							<span>Advertisement  540px X 80px</span>
						</div>
						<div class="jf-jobdetails">
							<div class="jf-jobdetaildescription">
								<div class="jf-title">
									<h2>Description</h2>
								</div>
								<div class="jf-jobdescription">
								<?= html_entity_decode($details->description)?>
								</div>
							</div>
						</div>
						<div class="jf-similarjobs" style="padding-top:50px">
                            <div class="jf-sectionhead">
                                <h2>Recent Blogs</h2>
                            </div>
                            <div class="jf-featuredjobs">
                            <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="jf-featurejobholder">
								<div class="jf-featurejob">
									<figure class="jf-companyimg">
										<?php if($recent->image != null): ?>
											<img src="<?php echo e(asset($recent->image)); ?>" alt="image description" style="height: 45px;">
										<?php else: ?>
											<img src="<?php echo e(asset('assets/images/image-default.png')); ?>" style="height:45px" alt="image description">
										<?php endif; ?>
									</figure>
									<div class="jf-companycontent">
										<div class="jf-companyname">
											<h3><a href="<?php echo e(route('disease.detail',['id'=>$recent->id])); ?>"><?php echo e(str_limit($recent->name,20)); ?></a></h3>
											<span>Posted On: <?php echo e(\Carbon\Carbon::parse($recent->created_at)->format('M d, Y')); ?></span>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-3 float-left">
						<aside id="jf-sidebar" class="jf-sidebar jf-sidebarvtwo">
							<div class="jf-widget jf-myrecentrearches">
								<div class="jf-widgettitle">
									<h3>Categories</h3>
								</div>
								<ul class="jf-recentsearches">
                                <?php 
                                    $arr = (explode(",",$details->category ));
                                    for($i=0;$i<count($arr);$i++){?>
                                    <li>
                                        <a href="javascript:void(0);">
                                        <?php echo $arr[$i];?>
                                        </a>
                                    </li>
                                <?php
                                    }
                                ?>
                                </ul>
							</div>
							<?php if($details->hide_publisher== 0): ?>
							<div class="jf-widget jf-employerweek">
                                <div class="jf-widgettitle">
                                    <h3>Author</h3>
                                </div>
                                <div class="jf-angrycreative">
                                    <img src="<?php echo e(asset($details->abc->profile_image)); ?>" alt="img description">
                                </div>
                                <div class="jf-employerdetails">
                                    <h3><?php echo e($details->abc->name); ?></h3>
                                    <h4><span>Member Since: <?php echo e(\Carbon\Carbon::parse($details->abc->created_at)->format('M d, Y')); ?></span>
                                    </h4>
                                </div>
                            </div>
							<?php endif; ?>
							<div class="jf-adds jf-jobsearchadd">
								<a href="javascript:void(0);" title="">
									<figure>	
										<img src="<?php echo e(asset('assets/images/adds-02.jpg')); ?>" alt="img description">
									</figure>
								</a>
								<span>Advertisement  540px X 80px</span>
							</div>
						</aside>
					</div>
				</div>
			</div>
		</div>
	</div>
	</main>
	<script>
	var videoUrl = $('.video_url').data('video');  
	if(videoUrl!=""){
		var videoId = getId(videoUrl);
		$('.video_url').html('<iframe width="560" height="315" src="//www.youtube.com/embed/' + videoId + '" frameborder="0" allowfullscreen></iframe>');
	}
	function getId(url = "video") {
		var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
		var match = url.match(regExp);

		if (match && match[2].length == 11) {
			return match[2];
		} else {
			return 'error';
		}
	}
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ypr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/article_detail.blade.php ENDPATH**/ ?>