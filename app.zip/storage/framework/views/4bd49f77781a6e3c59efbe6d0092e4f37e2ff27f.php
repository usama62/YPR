<?php $__env->startSection('content'); ?>
    <div id="jf-dashboardbanner" class="jf-dashboardbanner">
        <h1>Categories</h1>
        <ol class="jf-breadcrumb">
            <li><a href="javascript:void(0);">Dashboard</a></li>
            <li><a href="javascript:void(0);">Manage Categories</a></li>
        </ol>
    </div>
    <main id="jf-main" class="jf-main jf-haslayout">
        <div class="jf-dbsectionspace jf-haslayout">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="jf-dashboardbox jf-myappliedjobs">
                        <div class="jf-dashboardboxtitle jf-dashboardboxtitlevtwo">
                            <div class="jf-title">
                                <h2>Manage Categories</h2>
                            </div>
                            <form class="jf-formtheme jf-questsearch" action="<?php echo e(route('category.search')); ?>">
                                <fieldset>
                                    <div class="form-group jf-inputwithicon">
                                        <i class="lnr lnr-magnifier"></i>
                                        <input type="text" name="s" class="form-control" placeholder="Search Here">
                                    </div>
                                    <button type="submit" class="jf-btn jf-active btn-primary"><i class="lnr lnr-magnifier"></i></button>
                                </fieldset>
                            </form>
                        </div>
                        <div class="jf-dashbboardcontent jf-myjobsapplications">
                            <ul>
                                <div style="padding: 30px 20px;">
                                    <?php if(session()->has('message')): ?>
                                        <div class="alert alert-<?php echo e(session('class')); ?>"><?php echo e(session("message")); ?></div>
                                    <?php endif; ?>
                                </div>
                                <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <div class="jf-featurejob">
                                        <div class="jf-companycontent jf-companycontentvtwo">
                                            <div class="jf-companyname">
                                                <h3><?php echo e($cat->name); ?></h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="jf-featurejob" style="width:35%">
                                        <div class="jf-companycontent jf-companycontentvtwo">
                                            <div class="jf-companyname">
                                                <h5>Category Type</h5>
                                                <?php if($cat->parent_id == null): ?>
                                                <span>Base</span>
                                                <?php else: ?>
                                                <span><?php echo e($cat->parent->name); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="jf-btnjobalerts jf-btnjobalertsvthree" style="padding: 50px 25px;">
                                    <li class="jf-btneditjob"><a href="<?php echo e(route('category.edit',['id'=>$cat->id])); ?>"><i class="ti-pencil"></i></a></li>
                                        <li class="jf-btndell"><a onclick="return confirm('Are you sure?')" href="<?php echo e(route('category.delete',['id'=>$cat->id])); ?>"><i class="ti-trash"></i></a></li>
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center" style="padding-top:100px;padding-bottom:100px;">
                                        <img src="<?php echo e(asset('assets/images/no-record.png')); ?>" alt="image description">
                                        <p>No Data Found</p>
                                    </div>	
                                <?php endif; ?>	
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="jf-pagination">
            <?php if(isset($_GET['s'])): ?>
                <?php echo e($category->appends(['s' => $_GET['s'] ])->links()); ?>

            <?php else: ?>
                <?php echo e($category->links()); ?>

            <?php endif; ?>
        </nav>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/admin/category/manage.blade.php ENDPATH**/ ?>