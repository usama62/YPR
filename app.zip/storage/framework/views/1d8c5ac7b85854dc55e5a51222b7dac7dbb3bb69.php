<?php $__env->startSection('content'); ?>
<main id="jf-main" class="jf-main jf-haslayout">
			<!--************************************
					Update Button Area Start
			*************************************-->
			<div class="jf-dbsectionspace jf-haslayout">
				<div class="jf-updatall">
					<?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                        </div>
					<?php endif; ?>
					<?php 
					$posts = \App\User::where(['id' => auth::user()->id])->first();	
					if($posts->status == 1){				
					?>
					<?php echo e(__('Your have been blocked, Contact admin for further query.')); ?>

					<?php }else{?>
                    <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

					<?php echo e(__('If you did not receive the email')); ?>, <a href="<?php echo e(route('verification.resend')); ?>"><?php echo e(__('click here to request another')); ?></a>.
					<?php }?>
				</div>
			</div>
			<!--************************************
					Update Button Area End
			*************************************-->
		</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/auth/verify.blade.php ENDPATH**/ ?>