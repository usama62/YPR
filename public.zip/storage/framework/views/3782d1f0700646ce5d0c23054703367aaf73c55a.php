<?php $__env->startSection('content'); ?>
    <div id="jf-dashboardbanner" class="jf-dashboardbanner">
        <h1>Users</h1>
        <ol class="jf-breadcrumb">
            <li><a href="javascript:void(0);">Dashboard</a></li>
            <li><a href="javascript:void(0);">Edit Users</a></li>
        </ol>
    </div>
		<main id="jf-main" class="jf-main jf-haslayout">
			<div class="jf-dbtwocolumns jf-haslayout">
				<div class="row">
					<div class="col-12 col-sm-12 col-md-12 col-lg-9">
						<div class="jf-dbsectionspace jf-haslayout">
							<div class="jf-dashboardbox">
								<div class="jf-dashboardboxtitle">
									<h2>Edit User</h2>
                                    <span>Edit User Details</span>
                                    <div class="profile_image">
                                        <?php if($user->profile_image != null): ?>
                                            <img src="<?php echo e(asset($user->profile_image)); ?>" alt="image description">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/images/default-user-profile-image.png')); ?>" alt="image description">
                                        <?php endif; ?>
                                    </div>
								</div>
								<div class="jf-dashbboardcontent">
									<form method="POST" action="<?php echo e(route('user.update',$user->id)); ?>" enctype="multipart/form-data" class="jf-formtheme jf-postajobform">
										<?php echo csrf_field(); ?>
										<fieldset>	
											<div class="form-group jf-inputwithicon">
												<input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<input type="password" name="password" class="form-control" value="<?php echo e($user->password); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<input type="text" name="phone" class="form-control" value="<?php echo e($user->phone); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<input type="text" name="age" class="form-control" value="<?php echo e($user->age); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<span class="jf-select">
													<select name="gender" required>
														<option>Gender</option>
														<option value="male" <?php if($user->gender == 'male'): ?> selected <?php endif; ?> >Male</option>
														<option value="female" <?php if($user->gender == 'female'): ?> selected <?php endif; ?> >Female</option>
													</select>
												</span>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<input type="text" name="disease" class="form-control" value="<?php echo e($user->disease); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<input type="text" name="pills" class="form-control" value="<?php echo e($user->pills); ?>" required>
                                            </div>
                                            <div class="form-group jf-inputwithicon">
												<span class="jf-select">
													<select name="role" required>
														<option value="">Role</option>
														<option value="1" <?php if($user->role == 1): ?> selected <?php endif; ?> >Admin</option>
														<option value="0" <?php if($user->role == 0): ?> selected <?php endif; ?> >User</option>
													</select>
												</span>
                                            </div>
											<div class="form-group jf-inputwithicon jf-textarea">
												<textarea type="text" name="address" value="<?php echo e($user->name); ?>" style="height:150px"  required></textarea>
											</div>
											<fieldset class="jf-dragdropimg">
												<div class="jf-inputtyfile">
													<label for="jf-uploadimg">
														<div>
															<img id="profile-img-tag" src="<?php echo e($user->profile_image); ?>" style="height:150px" alt="">
														</div>
														<span>Update profile picture Here <a href="javascript:void(0);">Browse</a></span>
														<em>Maximum upload file size: 500 KB Maximum image size: 300px X 300px</em>
														<input type="file" name="profile_image" id="jf-uploadimg">
														<input type="hidden" name="profile_image_hidden" id="jf-uploadimg" value="<?php echo e($user->profile_image); ?>">
													</label>
												</div>
											</fieldset>
                                            <div class="form-group jf-inputwithicon jf-textarea">
                                                <button type="submit" class="jf-btn jf-active btn-primary"><?php echo e(__('Save')); ?></button>
                                            </div>
										</fieldset>
									</form>									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</main>
		<script>
			function readURL(input) {
				if (input.files && input.files[0]) {
					var reader = new FileReader();
					
					reader.onload = function (e) {
						$('#profile-img-tag').attr('src', e.target.result);
					}
					reader.readAsDataURL(input.files[0]);
				}
			}
				$("#jf-uploadimg").change(function(){
					readURL(this);
				});
		</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>