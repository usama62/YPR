<?php $__env->startSection('content'); ?>
    <div id="jf-dashboardbanner" class="jf-dashboardbanner">
        <h1>Health</h1>
        <ol class="jf-breadcrumb">
            <li><a href="javascript:void(0);">Dashboard</a></li>
            <li><a href="javascript:void(0);">Health</a></li>
        </ol>
    </div>
    <main id="jf-main" class="jf-main jf-haslayout">
        <div class="jf-dbsectionspace jf-haslayout">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="jf-dashboardbox jf-myappliedjobs">
                        <div class="jf-dashboardboxtitle jf-dashboardboxtitlevtwo">
                            <div class="jf-title">
                                <h2>Health</h2>
                                <span>Health info</span>
                            </div>
                        </div>
                        <div class="jf-dashbboardcontent jf-myjobsapplications">
                            <ul>
                                <div style="padding: 30px 20px;">
                                    <?php if(session()->has('message')): ?>
                                        <div class="alert alert-<?php echo e(session('class')); ?>"><?php echo e(session("message")); ?></div>
                                    <?php endif; ?>
                                </div>

                                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <div class="jf-featurejob">
                                        <figure class="jf-companyimg">
                                            <img src="<?php echo e($post->image); ?>" alt="image description">
                                        </figure>
                                        <div class="jf-companycontent">
                                            <div class="jf-companyname">
                                                <h3><a href="javascript:void(0);"><?php echo e($post->title); ?></a></h3>
                                                <span><?php echo e($post->categories); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="jf-btnjobalerts jf-btnjobalertsvtwo">
                                    
                                    <li class="jf-btnnewwindow"><a href="<?php echo e(route('health.detail',['id'=>$post->id])); ?>"><i class="ti-new-window"></i></a></li>
                                        <li class="jf-btneditjob"><a href="<?php echo e(route('health.edit',['id'=>$post->id])); ?>"><i class="ti-pencil"></i></a></li>
                                        <li class="jf-btndell"><a href="<?php echo e(route('health.delete',['id'=>$post->id])); ?>"><i class="ti-trash"></i></a></li>
                                    </ul>
                                    <ul class="jf-jobmatadata">
                                        <li>
                                            <i class="ti-calendar"></i>
                                            <div class="jf-matacontent">
                                                <span>Posted On</span>
                                                <time datetime="2019-12-12"><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('M d, Y')); ?></time>
                                            </div>
                                        </li>
                                        <li>
                                            <i class="ti-bell"></i>
                                            <div class="jf-matacontent">
                                                    <span>Status</span>
													<?php if($post->status == "pending"): ?>
													    <a class="jf-btnjobtag jf-internship" href="javascript:void(0);"><?php echo e($post->status); ?></a>
													<?php elseif($post->status == "publish"): ?>
													    <a class="jf-btnjobtag jf-parttimejob" href="javascript:void(0);"><?php echo e($post->status); ?></a>
													<?php else: ?>
													    <a class="jf-btnjobtag jf-projectbasejob" href="javascript:void(0);"><?php echo e($post->status); ?></a>
													<?php endif; ?>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<div class="text-center" style="padding-top:100px;padding-bottom:100px;">
										<img src="<?php echo e(asset('assets/images/no-record.png')); ?>" alt="image description">
										<p>No Data Found</p>
									</div>	
                                <?php endif; ?>	
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="jf-pagination">
            <?php echo e($posts->links()); ?>

        </nav>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/admin/health/manage.blade.php ENDPATH**/ ?>