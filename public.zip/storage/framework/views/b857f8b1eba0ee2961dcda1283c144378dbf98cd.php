<?php $__env->startSection('content'); ?>
    <div class="jf-breadcrumbarea">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <ol class="jf-breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li class="jf-active">Videos</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <main id="jf-main" class="jf-main jf-haslayout">
        <div class="jf-sectionspace">
            <div class="container">
                <div class="row">
                    <div id="jf-twocolumns" class="jf-twocolumns">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 pull-right">
                            <div id="jf-content" class="jf-content">
                                <div class="jf-innersectionhead">
                                    <div class="jf-title">
                                        <h2>Latest Videos</h2>
                                        <span>Stay Updated With Our Latest Videos</span>
                                    </div>
                                </div>
                                <div class="jf-sortandview">
                                    <div class="jf-widget jf-widgetsearch">
                                        <div class="jf-widgettitle">
                                            <h3>Start Search Here</h3>
                                        </div>
                                        <div class="jf-widgetcontent">
                                            <form class="jf-formtheme">
                                                <fieldset>
                                                    <div class="form-group jf-inputwithicon" style="width: 80%";>
                                                        <i class="lnr lnr-magnifier"></i>
                                                        <input type="search" name="search" class="form-control" placeholder="Search Here">
                                                    </div>
                                                    <button class="jf-btn" type="button" style="padding: 5px 42px;margin-left:5px;">Search Now</button>
                                                </fieldset>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="jf-posts jf-postsgrid">
                                    <div class="row">
                                        <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 float-left">
                                            <article class="jf-newsarticle">
                                                <figure class="jf-newsimg">
                                                    <span class="jf-posttag"><i class="fas fa-ellipsis-v"></i></span>
                                                    <div class="wt-project video_url" data-video="<?php echo e($video->video_link); ?>" style="width: 100%;"></div>
                                                </figure>
                                                <div class="jf-postauthorname">
                                                    <div class="jf-articlecontent">
                                                        <div class="jf-articletitle">
                                                            <h3><a href="<?php echo e(route('video.detail',['id'=>$video->id])); ?>"><?php echo e($video->title); ?></a></h3>
                                                        </div>
                                                        <span><?php echo e(str_limit($video->description, 40)); ?></span>
                                                    </div>
                                                </div>
                                                <ul class="jf-postarticlemeta">
                                                    <li>
                                                        <i class="lnr lnr-calendar-full"></i>
                                                        <span><?php echo e(\Carbon\Carbon::parse($video->created_at)->format('M d, Y')); ?></span>
                                                    </li>
                                                    <li>
                                                        <i id="wish_list_icon_<?php echo e($video->id); ?>" class="lnr lnr-heart"></i>
                                                        <span><a id="wish_list_text_<?php echo e($video->id); ?>" data-item="<?php echo e($video->id); ?>" class="wish_list">Click to Save</a></span>
                                                    </li>
                                                </ul>
                                            </article>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <div class="text-center" style="padding-top:100px;padding-bottom:100px;">
                                                <img src="<?php echo e(asset('assets/images/no-record.png')); ?>" alt="image description">
                                                <p>No Data Found</p>
                                            </div>	
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <nav class="jf-pagination">
                                    <?php echo e($videos->links()); ?>

                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>
        var videoUrl = $('.video_url').data('video');  
        if(videoUrl!=""){
            var videoId = getId(videoUrl);
            $('.video_url').html('<iframe width="560" height="315" src="//www.youtube.com/embed/' + videoId + '" frameborder="0" allowfullscreen></iframe>');
        }
        function getId(url = "video") {
            var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
            var match = url.match(regExp);

            if (match && match[2].length == 11) {
                return match[2];
            } else {
                return 'error';
            }
        }
    </script> 
    <script>   
        $(".wish_list").click(function(){
            var item_id = $(this).data('item');
            var _token = $("input[name=_token]").val();
            console.log(item_id);
            $.ajax({ 
                url: "<?php echo e(route('saved')); ?>",
                data: {item_id : item_id, _token : _token},
                type: 'post',
                success: function(response)
                {
                    console.log(response);
                    if(response > 0){
                        $('#wish_list_icon_'+response).removeClass('lnr lnr-heart');
                        $('#wish_list_icon_'+response).addClass('fa fa-heart-o');
                        $('#wish_list_text_'+response).text('saved');
                    }
                }
            });
        });    
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ypr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/video_listing.blade.php ENDPATH**/ ?>