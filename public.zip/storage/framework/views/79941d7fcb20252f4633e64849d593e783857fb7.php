<?php $__env->startSection('content'); ?>
    <!--************************************
				breadcrumbarea start
    *************************************-->
    <div class="jf-breadcrumbarea">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <ol class="jf-breadcrumb">
                        <li><a href="index-2.html">Home</a></li>
                        <li>Drugs & supplements</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <main id="jf-main" class="jf-main jf-haslayout">
        <div class="jf-sectionspace jf-haslayout">
            <div class="jf-haslayout">
                <div class="container">
                    <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4" style="margin-top:20px">
                            <div class="jf-candidatessearchsvtwo">
                                <div class="jf-candidatessearcgrid jf-verticaltop"  style="width:100% !important">
                                    <div class="jf-candidatessearch">
                                        <figure class="jf-candidatescover">
                                            <img src="<?php echo e(asset($value->image)); ?>" alt="img-description" style="height: 250px;">	
                                        </figure>
                                        <figure>
                                            <?php if($value->abc->profile_image != null): ?>
                                            <img src="<?php echo e(asset($value->abc->profile_image)); ?>" alt="image description" style="height: 72px;">
                                            <?php else: ?>
                                            <img src="<?php echo e(asset('assets/images/successstory/grid/img-01.png')); ?>" alt="image description">
                                            <?php endif; ?>
                                        </figure>
                                        <div class="jf-employerdetails">
                                            <a href="<?php echo e(route('drugs.detail',['id'=>$value->id])); ?>"><h3><?php echo e($value->title); ?></h3></a>
                                            <h4><span>Author: <?php echo e($value->abc->name); ?></span></h4>
                                            <span>
                                                <span>Posted On</span>
                                                <span><?php echo e(\Carbon\Carbon::parse($value->created_at)->format('M d, Y')); ?></span>
                                            </span>
                                            <span style="float:right">
                                                <?php
                                                    $saved_item= App\Saved::where(['user_id' => Auth::user()->id, 'post_id' =>$value->id])->get();
                                                ?>
                                                <?php if(count($saved_item) > 0): ?>
                                                <i id="wish_list_icon_<?php echo e($value->id); ?>" class="fa fa-heart-o filled" ></i>
                                                <?php else: ?>
                                                <i id="wish_list_icon_<?php echo e($value->id); ?>" class="fa fa-heart-o"></i>
                                                <?php endif; ?>
                                                <span><a id="wish_list_text_<?php echo e($value->id); ?>" data-item="<?php echo e($value->id); ?>" class="wish_list" style="cursor:pointer"><?php if(count($saved_item) > 0): ?>Saved <?php else: ?> Click to Save <?php endif; ?></a></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center" style="padding-top:100px;padding-bottom:100px;">
                                <img src="<?php echo e(asset('assets/images/no-record.png')); ?>" alt="image description">
                                <p>No Data Found</p>
                            </div>	
                        <?php endif; ?>
                        <nav class="jf-pagination">
                            <?php echo e($values->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ypr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/drugs_listing.blade.php ENDPATH**/ ?>