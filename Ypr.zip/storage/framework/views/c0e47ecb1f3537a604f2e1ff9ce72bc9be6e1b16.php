<?php $__env->startSection('content'); ?>
<main id="jf-main" class="jf-main jf-haslayout">
			<!--************************************
					Chart Statistics Start
			*************************************-->
			<div class="jf-dbsectionspace jf-haslayout">
				<div class="row">
					<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
						<div class="jf-dashboardbox jf-basicformholder">
							<div class="jf-dashboardboxtitle">
								<h2>Basic Information</h2>
								<span>Add Your Details</span>
							</div>
							<div class="jf-dashbboardcontent jf-basicinfo">
								<form class="jf-formtheme jf-formbasicinfo">
                                    <?php echo csrf_field(); ?>
									<fieldset>
                                        <div class="form-group jf-inputwithicon">
											<input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e(auth::user()->name); ?>">
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="text" name="phone" class="form-control" placeholder="<?php echo e(auth::user()->phone); ?>">
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="email" name="email" class="form-control" placeholder="<?php echo e(auth::user()->email); ?>">
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="text" name="age" class="form-control jf-unstyled" placeholder="Age" required>
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="text" name="gender" class="form-control jf-unstyled" placeholder="Gender" required>
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="text" name="disease" class="form-control jf-unstyled" placeholder="Disease if any">
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="text" name="pills" class="form-control jf-unstyled" placeholder="Names of Pills taking if any">
										</div>
										<div class="form-group jf-inputwithicon">
											<input type="text" name="address" class="form-control" placeholder="Address">
										</div>
										<div class="form-group jf-btnsarea">
                                            <button type="submit" class="jf-btn jf-active btn-primary"><?php echo e(__('Save & Update')); ?></button>
                                        </div>
									</fieldset>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--************************************
					Chart Statistics End
			*************************************-->
		</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/profile.blade.php ENDPATH**/ ?>