<?php $__env->startSection('content'); ?>    
    <div id="jf-dashboardbanner" class="jf-dashboardbanner">
        <h1>Saved Items</h1>
        <ol class="jf-breadcrumb">
            <li><a href="javascript:void(0);">Dashboard</a></li>
            <li><a href="javascript:void(0);">Saved Items</a></li>
        </ol>
    </div>
    <main id="jf-main" class="jf-main jf-haslayout">
        <div class="jf-dbsectionspace jf-haslayout">
            <div class="row">
                <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="jf-dashboardbox jf-myfavortejobs">
                        <div class="jf-dashboardboxtitle">
                            <h2>Saved Items</h2>
                            <span>Your Saved Items</span>
                        </div>
                        <div class="jf-dashbboardcontent">
                            <div style="padding: 30px 20px;">
                                <?php if(session()->has('message')): ?>
                                    <div class="alert alert-<?php echo e(session('class')); ?>"><?php echo e(session("message")); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php $__empty_1 = true; $__currentLoopData = $saved_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saved_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="jf-featurejob">
                                <figure class="jf-companyimg">
                                    <?php if($saved_item->posts->image != null): ?>
                                    <img src="<?php echo e(asset($saved_item->posts->image)); ?>" alt="image description">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('assets/images/image-default.png')); ?>" alt="image description">
                                    <?php endif; ?>
                                </figure>
                                <div class="jf-companycontent">
                                    <div class="jf-companyname" style="width:75%">
                                        <h3><a href="javascript:void(0);"><?php echo e($saved_item->posts->title); ?></a></h3>
                                        <span><?php echo e($saved_item->posts->categories); ?></span>
                                    </div>
                                    <div style="float:right">
                                        <?php if($saved_item->posts->post_type == "Health"): ?>
                                            <a class="jf-btn" href="<?php echo e(route('health.detail',['id'=>$saved_item->posts->id])); ?>">Details</a>
                                        <?php elseif($saved_item->posts->post_type == "Disease"): ?>
                                            <a class="jf-btn" href="<?php echo e(route('disease.detail',['id'=>$saved_item->posts->id])); ?>">Details</a>
                                        <?php else: ?>
                                            <a class="jf-btn" href="<?php echo e(route('drugs.detail',['id'=>$saved_item->posts->id])); ?>">Details</a>
                                        <?php endif; ?>
                                            <a class="jf-btn" href="<?php echo e(route('saved.delete',['id'=>$saved_item->id])); ?>">Remove</a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center" style="padding-top:100px;padding-bottom:100px;">
                                    <img src="<?php echo e(asset('assets/images/no-record.png')); ?>" alt="image description">
                                    <p>No Data Found</p>
                                </div>	
                            <?php endif; ?>	
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="jf-pagination">
            <?php echo e($saved_items->links()); ?>

        </nav>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/admin/saveditems.blade.php ENDPATH**/ ?>