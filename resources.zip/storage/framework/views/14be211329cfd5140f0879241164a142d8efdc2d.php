<?php $__env->startSection('content'); ?>
<div class="container">
    <?= html_entity_decode($pages->content)?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ypr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\YPR\resources\views/page.blade.php ENDPATH**/ ?>